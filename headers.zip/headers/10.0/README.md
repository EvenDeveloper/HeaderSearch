##iOS 10 SpringBoard Headers
Generated from an iPhone 5s iOS 10 IPSW; extracted using class-dump.
